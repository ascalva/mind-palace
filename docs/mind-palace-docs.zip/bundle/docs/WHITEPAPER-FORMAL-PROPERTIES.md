# The Mind Palace — Verifiable Properties, Proof Obligations & Exposed Gaps
### Formal companion II to `WHITEPAPER.md` / `WHITEPAPER-TECHNICAL.md`

This document turns the design's invariants into a **verification plan**: each is stated
formally, classified by *how strongly it can be guaranteed*, and paired with the obligation that
discharges it. It also records the **gaps formalization exposed** — the real payoff.

## The honest boundary
Formalization here buys **specification precision**, **verifiable properties**, and
**gap-surfacing**. It does **not** buy end-to-end proof: LLM output quality, native/OS code, and
hardware are **assumption-bounded**, not provable. The strongest assurance is *structural* —
the wrong state cannot be constructed — which needs no test at all.

### Assurance hierarchy (push every invariant as high as it goes)
1. **Structural / unrepresentable** — illegal state cannot be built (typed handle/view). *Proof = construction.*
2. **Static-checkable** — provable without running (import graph, signatures). *CI lint.*
3. **Runtime guard** — checked, fail-closed, before the dangerous act. *Assertion + test.*
4. **Property-tested** — invariant asserted over generated inputs. *Hypothesis/QuickCheck.*
5. **Assumption-bounded** — only boundable, with stated assumptions. *Documented limit.*

---

## Invariant catalog (the verification plan)

Let $\mathsf{Core}$ be the core module set, $\mathsf{Net}$ the network-capable modules,
$\to$ the import relation, $\mathcal{A}(\cdot)$ authority, $\rho$ provenance, $\mathsf{MR}$ the
mirror-readable classes, $\pi_{\mathsf{MR}}$ the mirror projection.

| # | Property (formal) | Tier | Discharge / obligation |
|---|---|---|---|
| I1 | egress: $\forall$ connect from core, $\mathrm{dst}\in\{\text{loopback},\text{AF\_UNIX}\}$ | guard + **assumption** | live test (external blocked) **+ stated assumption**: a native ext. opening its own socket bypasses a Python hook ⇒ OS isolation (pf/netns) is the real bound |
| I2 | no core→network path: $\nexists\,\text{path}\ \mathsf{Core}\!\to^{*}\!\mathsf{Net}$ | **static** | import-graph lint in CI (core may not import edge/sockets/http) — *promote from runtime to static* |
| I3 | model advises: no callsite executes model output as code/shell/cred outside the gate | **structural** + test | `Agent.respond` returns data, has no action path; dispatcher is the sole action path |
| I4 | sandbox powerless: $\mathcal{A}(\text{exec})\cap\{\text{net},\text{vault},\text{cred}\}=\varnothing$ | **structural** + guard | container `--network=none`, no mounts; integration test code can't reach net/vault |
| I5 | interpreted unforgeable: $\forall x\ \text{via DerivedStore},\ \rho(x)=\textsf{interpreted}$ | **structural** | by construction — *no provenance parameter exists* (exemplar of unrepresentable) |
| I6 | firewall: $\mathrm{in}(\Omega)\subseteq\pi_{\mathsf{MR}}(V)$ for introspective $\Omega$ | **prefilter (convention)** → promote | property test (observed never returned to mirror) **and** introduce a typed `MirrorView` so a non-MR view is *untypable* ⇒ structural |
| I7 | Constitution outermost: $\mathrm{frame}[0]=\textsf{Constitution}$, $\forall$ agents | structural + test | `frame_context` prepends; fingerprint test (exists) |
| I8 | ceiling: $\sum_{R}m\le C\ \wedge\ |R|\le2$ | guard + **FSM** | check-before-load; loader is a tiny FSM ⇒ *exhaustively checkable* |
| I9 | grounding: $\textsf{grounded}(A)\iff\mathrm{Cit}(A)\subseteq\mathrm{Ret}$ | property-test | Hypothesis: random answers w/ in- and out-of-set citations ⇒ predicate matches (**needs stable citation IDs — gap G1**) |
| I10 | recursion: $c(\kappa)\le\gamma^{d(\kappa)}g(\kappa)$, authored leaves only | property-test | Hypothesis over synthetic derivation DAGs ⇒ $c$ non-increasing in $d$; reject cycles (**needs persisted derivation edges — gap G2**) |
| I11 | belief ≠ utility: no $f$ maps $(c,u)\mapsto$ one ranking scalar | **structural** | two disjoint ranking APIs; review/test there is no combiner |
| I12 | gate: $s'=\Delta\!\cdot\!s$ iff $G(\Delta,s)$ else $s$; $\Delta$ never self-applies | structural + guard + **FSM** | only code applies $\Delta$; gate is a tiny FSM ⇒ checkable (**$\textsf{conforms}$ conjunct deferred — gap G5**) |
| I13 | authority non-widening: $\mathcal{A}(\text{agent}\oplus\varsigma)=\mathcal{A}(\text{agent})$; $\mathcal{A}(\mathrm{mint})=\mathrm{scope}\cap\textsf{MAX}$ | **structural** + test | skills add context not handles; dispatch table = held handles; property test over arbitrary skill composition |

The table **is** the build target: every row is either already structural (I3,I5,I11,I13), or names the
test/lint/promotion that discharges it.

---

## Safety vs liveness

**Safety** $\;\square\neg\text{bad}\;$ (enforce structurally): I1–I8, I11–I13 — the firewall holds, the
core never egresses, the gate never applies an unapproved/regressing change, the ceiling is never
exceeded, a fabricated answer never ships, authority never widens.

**Liveness** $\;\lozenge\,\text{good}\;$ (needs the supervisor's progress guarantees):
- every proposed change is *eventually* validated-or-rolled-back;
- $D(t)>\Theta$ *eventually* raises an alarm;
- a degraded router *eventually* falls back to rules;
- queued jobs *eventually* run.

The last is the dangerous one: under a perpetual foreground gate, low-priority cron (dreaming,
curation) can **starve**. Safety is free under the gate; liveness is not — **gap G6** below.

---

## Composition & non-interference (what survives putting pieces together)
- **Zone non-interference.** I2 is a property of the *import closure*: if $\mathsf{Core}\not\to^{*}\mathsf{Net}$, no egress path exists **regardless of edge behavior** — composition cannot create one.
- **Authority monotonicity.** I13 is closed under composition: no sequence of skill/role additions raises $\mathcal{A}$ above $\mathrm{scope}\cap\textsf{MAX}$.
- **Provenance preservation.** $\rho$ is assigned at ingest and is *invariant under all downstream derivation*; the only mutator is the human promotion $\uparrow$. So no pipeline stage can launder $\textsf{observed}$ into $\textsf{authored}$.

---

## What formalization exposed (the payoff — pin these before hardening)
- **G1 — Citation identifier scheme.** $\mathrm{Cit}(A)\subseteq\mathrm{Ret}$ is only *decidable* with stable IDs. Decide: cite by content **digest** (or a stable note ID), never by fuzzy title. Until then I9 is ill-posed.
- **G2 — Persisted derivation edges + acyclicity.** $d(\kappa)$ and the decay I10 are *uncomputable* unless each interpreted node records its scaffolding refs and the DAG is acyclic. Add a `derived_from` edge set; enforce acyclicity on insert.
- **G3 — Typed `MirrorView`.** I6 is currently a call-site convention (pass `MR`). Introduce a `MirrorView` type the dreamer consumes, constructible *only* from $\pi_{\mathsf{MR}}$, so handing it observed data is a *type error* — promoting I6 from property-tested to structural.
- **G4 — Drift metric & tolerance.** $D(t)=d(\mu(s_t),B)$ needs a concrete *normalized* metric over a mixed profile (rates ⊕ conformance vector) and a chosen $\Theta$. Specify the metric and band before the Phase-11 gauge.
- **G5 — The gate's deferred conjunct.** $G$ includes $\textsf{conforms}(\cdot)$, but the subjective judge is deferred. State the **live** guard honestly: $G_{\text{now}}=\textsf{approved}\wedge\text{golden}\ge B\wedge D\le\Theta$ (no $\textsf{conforms}$ yet). Do not let the formula overclaim.
- **G6 — Cron liveness / anti-starvation.** Add an aging policy (priority floor that rises with wait time) so background work *eventually* runs under sustained foreground use. Otherwise dreaming/curation can starve indefinitely — a silent liveness failure.
- **G7 — Free parameters.** $\gamma,\lambda,\sigma,k,h$ are unset. Declare bounds/calibration (e.g. $\gamma$ small enough that depth-3 is clearly subordinate; $\sigma$ tuned on the real corpus), not magic numbers.
- **G8 — Don't over-formalize.** The provenance preorder $\preceq$ is asserted but only the *set* $\mathsf{MR}$ is load-bearing today. Either use the ordering somewhere real or drop the claim — formalism should constrain, not decorate.

---

## Techniques to apply (practical, in priority order)
1. **Make illegal states unrepresentable** (highest leverage): typed `MirrorView` (G3), citation-ID type (G1), `derived_from` with acyclic insert (G2). These *delete* whole test categories.
2. **Static import-graph lint** for I2 (e.g. an import-linter contract: `core` cannot import `edge`/sockets/HTTP).
3. **Exhaustive FSM checks** for the two tiny machines — the two-slot loader (I8) and the gate (I12) — their state spaces are small enough to enumerate.
4. **Property-based tests** (Hypothesis) for I6, I9, I10, I13 — the predicates over generated inputs.
5. **Runtime fail-closed guards** remain for I1, I8, I12; keep the I1 *assumption* (native bypass) documented and back it with OS isolation before any networked phase.

## Thesis
Each line of philosophy compiles to an invariant; each invariant has a tier and a discharge; the
highest-value move is to make the wrong thing *unrepresentable* rather than merely *tested*. The
single best outcome of writing this down was **exposing G1–G8** — which is exactly what
formalization is for: catching the underspecified before it ships.
